def doGet(request, session):
# WebDev handler BODY for: POST /system/webdev/cookbook/named_query_run
#
# PASTE THIS INTO DESIGNER'S Web Dev resource editor for the `named_query_run`
# resource, POST tab (enable POST first — Designer starts new resources with
# only GET enabled).
#
# Request body (JSON): {"path": "<queryPath>", "params": {<optional params>}}
#   path: named query path relative to the project (e.g. "test_query" or "cookbook/test_query")
#   params: dict of named query parameters (may be empty {})
# Wraps system.db.runNamedQuery and converts the Dataset to a list of dicts.
# HTTP 200 always; caller checks the "ok" field.

    import json

    def _to_py(v):
        """Convert a Java/Jython Dataset cell value to a JSON-serializable Python type."""
        if v is None:
            return None
        t = type(v).__name__
        if t in ('bool', 'int', 'long', 'float', 'str', 'unicode'):
            return v
        if hasattr(v, 'getTime'):  # java.util.Date subclass
            return int(v.getTime())
        if hasattr(v, 'intValue') and hasattr(v, 'doubleValue'):  # java.lang.Number
            s = str(v)
            try:
                return int(s) if '.' not in s else float(s)
            except (ValueError, TypeError):
                pass
        return unicode(str(v))

    try:
        raw = request.get('data') or ''
        if not isinstance(raw, (str, unicode)):
            try:
                raw = raw.read()
            except Exception:
                raw = str(raw)

        body = {}
        if raw.strip():
            try:
                body = json.loads(raw)
            except ValueError as e:
                return {
                    "contentType": "application/json",
                    "response": json.dumps({"ok": False, "error": "Bad JSON body: " + str(e)})
                }

        path = body.get('path', '')
        if not path:
            return {
                "contentType": "application/json",
                "response": json.dumps({"ok": False, "error": "Missing 'path' in request body"})
            }

        params = body.get('params') or {}
        # Runs in this WebDev resource's project context ("cookbook"). If you get
        # "query not found", check the path (e.g. "test_query" not "cookbook/test_query").
        ds = system.db.runNamedQuery(path, params)

        cols = list(ds.columnNames)
        rows = []
        for r in range(ds.rowCount):
            row = {}
            for c, col in enumerate(cols):
                row[col] = _to_py(ds.getValueAt(r, c))
            rows.append(row)

        return {
            "contentType": "application/json",
            "response": json.dumps({
                "ok": True,
                "columns": cols,
                "data": rows,
                "rowCount": ds.rowCount
            })
        }
    except Exception as e:
        return {
            "contentType": "application/json",
            "response": json.dumps({"ok": False, "error": str(e)})
        }