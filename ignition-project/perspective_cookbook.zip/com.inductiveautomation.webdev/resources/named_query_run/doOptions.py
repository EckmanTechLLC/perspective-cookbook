def doOptions(request, session):
