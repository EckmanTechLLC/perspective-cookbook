def doPost(request, session):
# WebDev handler BODY for: POST /system/webdev/cookbook/named_query_run
#
# PASTE THIS INTO DESIGNER'S Web Dev resource editor for the `named_query_run`
# resource, POST tab (enable POST first — Designer starts new resources with
# only GET enabled).
#
# Request body (JSON): {"path": "<queryPath>", "params": {<optional params>}}
#   path: named query path relative to the project (e.g. "test_query" or "cookbook/test_query")
#   params: dict of named query parameters (may be empty {})
# Wraps system.db.runNamedQuery and converts the Dataset to a list of dicts.
# HTTP 200 always; caller checks the "ok" field.

    import json

    def _to_py(v):
        """Convert a Java/Jython Dataset cell value to a JSON-serializable Python type."""
        if v is None:
            return None
        t = type(v).__name__
        if t in ('bool', 'int', 'long', 'float', 'str', 'unicode'):
            return v
        if hasattr(v, 'getTime'):  # java.util.Date subclass
            return int(v.getTime())
        if hasattr(v, 'intValue') and hasattr(v, 'doubleValue'):  # java.lang.Number
            s = str(v)
            try:
                return int(s) if '.' not in s else float(s)
            except (ValueError, TypeError):
                pass
        return unicode(str(v))

    try:
        # IA WebDev auto-parses JSON bodies into Python dicts when
        # Content-Type is application/json. Handle dict, string, and
        # InputStream-ish inputs.
        raw = request.get('data')
        if isinstance(raw, dict):
            body = raw
        elif isinstance(raw, (str, unicode)):
            body = json.loads(raw) if raw.strip() else {}
        elif raw is None:
            body = {}
        else:
            try:
                body = json.loads(raw.read())
            except Exception as e:
                return {
                    "contentType": "application/json",
                    "response": json.dumps({"ok": False, "error": "Could not read body: " + str(e)})
                }

        path = body.get('path', '')
        if not path:
            return {
                "contentType": "application/json",
                "response": json.dumps({"ok": False, "error": "Missing 'path' in request body"})
            }

        params = body.get('params') or {}
        # Runs in this WebDev resource's project context ("cookbook"). If you get
        # "query not found", check the path (e.g. "test_query" not "cookbook/test_query").
        ds = system.db.runNamedQuery(path, params)

        cols = list(ds.columnNames)
        rows = []
        for r in range(ds.rowCount):
            row = {}
            for c, col in enumerate(cols):
                row[col] = _to_py(ds.getValueAt(r, c))
            rows.append(row)

        return {
            "contentType": "application/json",
            "response": json.dumps({
                "ok": True,
                "columns": cols,
                "data": rows,
                "rowCount": ds.rowCount
            })
        }
    except Exception as e:
        return {
            "contentType": "application/json",
            "response": json.dumps({"ok": False, "error": str(e)})
        }