def doPut(request, session):
