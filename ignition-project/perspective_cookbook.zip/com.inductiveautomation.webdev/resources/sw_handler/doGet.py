def doGet(request, session):
    request['servletResponse'].setHeader('Service-Worker-Allowed', '/')
    request['servletResponse'].setHeader('Cache-Control', 'no-cache, no-store, must-revalidate')

    sw_js = r"""
// sw_worker.js - Perspective PWA Service Worker
// Served by Ignition WebDev at: /system/webdev/cookbook/sw_handler
// Registered with scope: / (requires Service-Worker-Allowed: / header)

var CACHE_NAME = 'perspective-cache-v1';

var PRECACHE_ASSETS = [
  '/system/perspective/client/cookbook',
  '/system/perspective/client/cookbook/SW_Demo'
];

var PASSTHROUGH = [
  '/system/pws/',
  '/system/ws/',
  '/system/gateway',
  '/system/DsData',
  '/system/tag',
  '/system/named-query',
  '/system/alarm',
  '/main/data',
];

self.addEventListener('install', function (event) {
  console.log('[SW] install - cache:', CACHE_NAME);
  event.waitUntil(
    caches.open(CACHE_NAME).then(function (cache) {
      return Promise.all(
        PRECACHE_ASSETS.map(function (url) {
          return cache.add(url).catch(function (err) {
            console.warn('[SW] pre-cache miss:', url, '-', err.message);
          });
        })
      );
    }).then(function () {
      console.log('[SW] install complete');
      return self.skipWaiting();
    })
  );
});

self.addEventListener('activate', function (event) {
  console.log('[SW] activate');
  event.waitUntil(
    caches.keys().then(function (names) {
      return Promise.all(
        names
          .filter(function (n) { return n !== CACHE_NAME; })
          .map(function (n) {
            console.log('[SW] deleting old cache:', n);
            return caches.delete(n);
          })
      );
    }).then(function () {
      return self.clients.claim();
    })
  );
});

self.addEventListener('fetch', function (event) {
  var req = event.request;
  var url;
  if (req.method !== 'GET') { return; }
  try { url = new URL(req.url); } catch (e) { return; }
  if (url.origin !== self.location.origin) { return; }
  for (var i = 0; i < PASSTHROUGH.length; i++) {
    if (url.pathname.indexOf(PASSTHROUGH[i]) === 0) { return; }
  }

  event.respondWith(
    caches.match(req).then(function (cached) {
        var networkFetch = fetch(req).then(function (resp) {
          if (resp && resp.ok && resp.type === 'basic') {
            if (url.pathname !== '/system/webdev/cookbook/sw_handler') {
              var clone = resp.clone();
              caches.open(CACHE_NAME).then(function (c) { c.put(req, clone); });
            }
          } 
          return resp;
        }).catch(function () { return null; });

      if (cached) { return cached; }

      return networkFetch.then(function (resp) {
        if (resp) { return resp; }
        if (req.mode === 'navigate') {
          return new Response(
            '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">' +
            '<meta name="viewport" content="width=device-width,initial-scale=1">' +
            '<title>Offline - Ignition</title>' +
            '<style>body{margin:0;font-family:system-ui,sans-serif;background:#1a1a2e;color:#e0e0e0;display:flex;align-items:center;justify-content:center;min-height:100vh}.card{text-align:center;padding:40px;max-width:420px}h1{font-size:3.5em;margin:0 0 8px}h2{margin:0 0 12px;font-weight:400;opacity:.85}p{opacity:.6;line-height:1.6;margin:0 0 20px}button{padding:11px 28px;background:#3d7ef8;color:#fff;border:none;border-radius:6px;font-size:1em;cursor:pointer}button:hover{background:#5a93ff}</style></head>' +
            '<body><div class="card"><h1>OFFLINE</h1><h2>You are offline</h2>' +
            '<p>Cannot reach the Ignition gateway.<br>The cached Perspective shell may still be available.<br>Live tag values will not update.</p>' +
            '<button onclick="location.reload()">Retry connection</button></div></body></html>',
            { status: 200, headers: { 'Content-Type': 'text/html; charset=utf-8' } }
          );
        }
        return new Response('Service unavailable (offline)', {
          status: 503,
          statusText: 'Service Unavailable'
        });
      });
    })
  );
});

self.addEventListener('message', function (event) {
  if (!event.data) { return; }
  if (event.data.type === 'SKIP_WAITING') { self.skipWaiting(); }
  if (event.data.type === 'GET_VERSION') {
    event.source.postMessage({ type: 'VERSION', version: CACHE_NAME });
  }
});
"""

    return {
        "contentType": "application/javascript; charset=utf-8",
        "response": sw_js.strip()
    }