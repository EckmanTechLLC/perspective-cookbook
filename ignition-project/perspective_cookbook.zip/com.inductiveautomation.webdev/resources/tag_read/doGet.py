def doGet(request, session):

# WebDev handler BODY for: GET /system/webdev/cookbook/tag_read?path=<tagPath>
#
# PASTE THIS INTO DESIGNER'S Web Dev resource editor for the `tag_read`
# resource, GET tab. Designer owns the `def doGet(request, session):` line —
# everything below is the BODY only (already indented to match Designer's
# wrapper).
#
# Wraps system.tag.readBlocking for one tag. HTTP 200 always; caller checks
# the "ok" field in the JSON body. require-auth = false to match the
# test_endpoint precedent.

    import json

    def _to_py(v):
        """Convert a Java/Jython value to a JSON-serializable Python type."""
        if v is None:
            return None
        t = type(v).__name__
        if t in ('bool', 'int', 'long', 'float', 'str', 'unicode'):
            return v
        if hasattr(v, 'getTime'):  # java.util.Date subclass
            return int(v.getTime())
        if hasattr(v, 'intValue') and hasattr(v, 'doubleValue'):  # java.lang.Number
            s = str(v)
            try:
                return int(s) if '.' not in s else float(s)
            except (ValueError, TypeError):
                pass
        return unicode(str(v))

    try:
        params = request.get('params') or {}
        path = params.get('path', '')
        if not path:
            return {
                "contentType": "application/json",
                "response": json.dumps({"ok": False, "error": "Missing 'path' query parameter"})
            }

        results = system.tag.readBlocking([path])
        qv = results[0]
        ts = qv.timestamp
        ts_ms = int(ts.getTime()) if ts is not None else None

        return {
            "contentType": "application/json",
            "response": json.dumps({
                "ok": True,
                "path": path,
                "value": _to_py(qv.value),
                "quality": str(qv.quality),
                "timestamp": ts_ms
            })
        }
    except Exception as e:
        return {
            "contentType": "application/json",
            "response": json.dumps({"ok": False, "error": str(e)})
        }