def doPost(request, session):
# WebDev handler BODY for: POST /system/webdev/cookbook/tag_write
#
# PASTE THIS INTO DESIGNER'S Web Dev resource editor for the `tag_write`
# resource, POST tab (enable POST in the tab's settings first — Designer
# starts new resources with only GET enabled).
#
# Request body (JSON): {"path": "<tagPath>", "value": <any>}
# Wraps system.tag.writeBlocking for one tag. HTTP 200 always; caller checks
# the "ok" field in the JSON body.

    import json

    try:
        # IA WebDev auto-parses JSON bodies into Python dicts when
        # Content-Type is application/json. Handle dict, string, and
        # InputStream-ish inputs.
        raw = request.get('data')
        if isinstance(raw, dict):
            body = raw
        elif isinstance(raw, (str, unicode)):
            body = json.loads(raw) if raw.strip() else {}
        elif raw is None:
            body = {}
        else:
            try:
                body = json.loads(raw.read())
            except Exception as e:
                return {
                    "contentType": "application/json",
                    "response": json.dumps({"ok": False, "error": "Could not read body: " + str(e)})
                }

        path = body.get('path', '')
        if not path:
            return {
                "contentType": "application/json",
                "response": json.dumps({"ok": False, "error": "Missing 'path' in request body"})
            }

        value = body.get('value')
        qualities = system.tag.writeBlocking([path], [value])
        qc = qualities[0]

        return {
            "contentType": "application/json",
            "response": json.dumps({"ok": True, "qualityCode": str(qc)})
        }
    except Exception as e:
        return {
            "contentType": "application/json",
            "response": json.dumps({"ok": False, "error": str(e)})
        }